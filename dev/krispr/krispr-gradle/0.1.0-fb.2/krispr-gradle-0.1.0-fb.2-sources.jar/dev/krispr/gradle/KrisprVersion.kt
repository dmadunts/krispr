package dev.krispr.gradle

/** Generated from the build's `version`. */
const val KRISPR_VERSION = "0.1.0-fb.2"
